screen_width, screen_height = 500, 500
'''
	steps:
	level handling
	color choosing (beginning)
	pixel art!
	publish
'''