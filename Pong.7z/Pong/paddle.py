import pygame
from pygame.locals import *
from settings import screen_width, screen_height


# This is the main paddle class
class Paddle(pygame.sprite.Sprite):
	def __init__(self, pos: tuple, paddle_type: str):
		super().__init__()
		self.type = paddle_type
		self.image = pygame.image.load('Paddle.png').convert_alpha()
		# We will have to pass where we want both of our paddles to be placed
		self.rect = self.image.get_rect(center=pos)

		# Standard vector for movement
		self.direction = pygame.math.Vector2(0, 0)

		# This is for the score
		self.score = 0

	# This method will only be called when needed
	def score_up(self):
		self.score += 1

	def get_user_input(self):
		# The paddle to be moved will depend on the type it is
		keys = pygame.key.get_pressed()
		if self.type == 'left':
			if keys[K_w]:
				self.direction.y = -5
			elif keys[K_s]:
				self.direction.y = 5
			elif keys[K_r]:
				self.score = 0
			else:
				self.direction.y = 0
		if self.type == 'right':
			if keys[K_UP]:
				self.direction.y = -5
			elif keys[K_DOWN]:
				self.direction.y = 5
			elif keys[K_r]:
				self.score = 0
			else:
				self.direction.y = 0

	# This is so that the paddles don't go off screen
	def bounds(self):
		if self.rect.top >= screen_height:
			self.rect.bottom = 0
		elif self.rect.bottom <= 0:
			self.rect.top = screen_height

	def update(self):
		self.get_user_input()
		self.bounds()
		self.rect.y += self.direction.y
