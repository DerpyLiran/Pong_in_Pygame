import pygame
from paddle import Paddle
from settings import *
from ball import Ball
from random import randint


class Game:
	# We need the window so we can draw stuff from within the class
	def __init__(self, display_surface):
		self.display_surface = display_surface
		# All paddles and their groups
		self.paddle_group = pygame.sprite.Group()
		self.paddle1 = Paddle((40, int(screen_width / 2)), 'left')
		self.paddle2 = Paddle((screen_width - 40, int(screen_width / 2)), 'right')
		self.paddle_group.add(self.paddle1, self.paddle2)

		# This will be for the ball and its GroupSingle
		self.ball = Ball()
		self.ball_group = pygame.sprite.GroupSingle()
		self.ball_group.add(self.ball)

		# Font
		self.font = pygame.font.Font('.font.ttf', 40)

		# Game Status
		self.status = 'playing'

	# This method is for checking collisions between the paddles and the ball
	def check_collision(self):
		# Left paddle OMG VECTORS ARE SOOO HELPFULL!
		if self.ball.rect.colliderect(self.paddle1.rect) and self.ball.direction.x < 0:
			self.ball.direction.x = randint(3, 7)
		# Right paddle
		elif self.ball.rect.colliderect(self.paddle2.rect) and self.ball.direction.x > 0:
			self.ball.direction.x = -randint(3, 7)

		# This is for the screen collisions
		if self.ball.rect.right >= screen_width:
			self.paddle1.score_up()
		elif self.ball.rect.left <= 0:
			self.paddle2.score_up()

	# This is for showing the score
	def show_score(self):

		# This is for paddle 1
		paddle_1_score = self.font.render(str(self.paddle1.score), False, 'white')
		self.display_surface.blit(paddle_1_score, ((screen_width / 2) - 30, 20))

		# This is for paddle 2
		paddle_2_score = self.font.render(str(self.paddle2.score), False, 'white')
		self.display_surface.blit(paddle_2_score, ((screen_width / 2) + 30, 20))

	def run(self):
		# Score
		self.show_score()
		
		# Line down middle
		self.line = pygame.draw.line(self.display_surface, 'white', (int(screen_width / 2), 0), (int(screen_width / 2), screen_height), 5)

		# Paddle
		self.paddle_group.update()
		self.paddle_group.draw(self.display_surface)

		# Ball
		self.ball_group.update()
		self.ball_group.draw(self.display_surface)

		# Collision checking
		self.check_collision()
