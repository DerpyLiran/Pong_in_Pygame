import pygame
from sys import exit
from pygame.locals import *
from game import Game
from settings import screen_width, screen_height


# General setup
pygame.init()
win = pygame.display.set_mode((screen_width, screen_height), vsync=True)
pygame.display.set_caption('Pygame Pong!')
clock = pygame.time.Clock()
game = Game(win)


while True:
	for event in pygame.event.get():
		if event.type == QUIT:
			pygame.quit()
			exit()

	# Drawing everything
	win.fill('grey')
	game.run()

	clock.tick(60)
	pygame.display.update()
