import pygame
from random import randint
from settings import *


# This is the ball class
class Ball(pygame.sprite.Sprite):
	def __init__(self):
		super().__init__()
		# Image
		self.image = pygame.image.load('Ball.png').convert_alpha()

		# Rect and movement
		self.rect = self.image.get_rect(center=((screen_width / 2), (screen_height / 2)))
		self.direction = pygame.math.Vector2()
		# We set the direction initially here so that it is set once
		self.direction.y = 7
		self.direction.x = 5

	def move_ball(self):

		# Y axes
		if self.rect.bottom >= screen_height:
			self.direction.y = -randint(3, 7)
		elif self.rect.top <= 0:
			self.direction.y = randint(3, 7)

		# X axes
		elif self.rect.right >= screen_width:
			self.direction.x = -randint(3, 7)
		elif self.rect.left <= 0:
			self.direction.x = randint(3, 7)

	def update(self):
		# Movement
		self.rect.y += self.direction.y
		self.rect.x += self.direction.x
		self.move_ball()
